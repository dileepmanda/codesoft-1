# codsoft_task3
a Currency Converter App as an Android Developer intern at CodSoft🚀💡 
It includes designing own widgets,Fetching latest currency rates from OpenExchangeRates API and storing rates inside local phone storage by using HIVE NoSQL database management tool for offline conversion.
Validating user inputs for both source and target currency also handling api error connections and internet problems by displaying error messages.
Implementing manual curreny rates update refresh button with simple UI designs.
